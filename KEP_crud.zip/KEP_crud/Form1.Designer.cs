﻿namespace KEP_crud
{
    partial class crud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(crud));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.X = new System.Windows.Forms.PictureBox();
            this.updbut = new System.Windows.Forms.Button();
            this.errorl = new System.Windows.Forms.Label();
            this.addb = new System.Windows.Forms.Button();
            this.timet = new System.Windows.Forms.TextBox();
            this.datet = new System.Windows.Forms.TextBox();
            this.addresst = new System.Windows.Forms.TextBox();
            this.typet = new System.Windows.Forms.TextBox();
            this.birthdayt = new System.Windows.Forms.TextBox();
            this.telet = new System.Windows.Forms.TextBox();
            this.emailt = new System.Windows.Forms.TextBox();
            this.namet = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.input = new System.Windows.Forms.TextBox();
            this.addpb = new System.Windows.Forms.Button();
            this.editb = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.requestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bday = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reytype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timereq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.req_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.requestBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(985, 619);
            this.panel1.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.AliceBlue;
            this.panel4.Controls.Add(this.panel2);
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 66);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(985, 553);
            this.panel4.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightBlue;
            this.panel2.Controls.Add(this.X);
            this.panel2.Controls.Add(this.updbut);
            this.panel2.Controls.Add(this.errorl);
            this.panel2.Controls.Add(this.addb);
            this.panel2.Controls.Add(this.timet);
            this.panel2.Controls.Add(this.datet);
            this.panel2.Controls.Add(this.addresst);
            this.panel2.Controls.Add(this.typet);
            this.panel2.Controls.Add(this.birthdayt);
            this.panel2.Controls.Add(this.telet);
            this.panel2.Controls.Add(this.emailt);
            this.panel2.Controls.Add(this.namet);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(985, 553);
            this.panel2.TabIndex = 1;
            this.panel2.Visible = false;
            // 
            // X
            // 
            this.X.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.X.BackColor = System.Drawing.Color.LightBlue;
            this.X.ErrorImage = null;
            this.X.Image = ((System.Drawing.Image)(resources.GetObject("X.Image")));
            this.X.Location = new System.Drawing.Point(852, 3);
            this.X.Name = "X";
            this.X.Size = new System.Drawing.Size(58, 51);
            this.X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.X.TabIndex = 11;
            this.X.TabStop = false;
            this.X.Click += new System.EventHandler(this.X_Click);
            // 
            // updbut
            // 
            this.updbut.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.updbut.BackColor = System.Drawing.Color.White;
            this.updbut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updbut.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updbut.Location = new System.Drawing.Point(448, 359);
            this.updbut.Name = "updbut";
            this.updbut.Size = new System.Drawing.Size(124, 44);
            this.updbut.TabIndex = 10;
            this.updbut.Text = "UPDATE";
            this.updbut.UseVisualStyleBackColor = false;
            this.updbut.Visible = false;
            this.updbut.Click += new System.EventHandler(this.upd_Click);
            // 
            // errorl
            // 
            this.errorl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.errorl.BackColor = System.Drawing.Color.Transparent;
            this.errorl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.errorl.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorl.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.errorl.Location = new System.Drawing.Point(329, 425);
            this.errorl.Name = "errorl";
            this.errorl.Size = new System.Drawing.Size(348, 99);
            this.errorl.TabIndex = 9;
            this.errorl.Text = "ERROR: LOREM IPSUM LOREM IPSUM LOREM IPSUM LOREM IPSUM";
            this.errorl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // addb
            // 
            this.addb.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.addb.BackColor = System.Drawing.Color.White;
            this.addb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addb.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addb.Location = new System.Drawing.Point(448, 359);
            this.addb.Name = "addb";
            this.addb.Size = new System.Drawing.Size(124, 44);
            this.addb.TabIndex = 8;
            this.addb.Text = "ADD";
            this.addb.UseVisualStyleBackColor = false;
            this.addb.Click += new System.EventHandler(this.addb_Click);
            // 
            // timet
            // 
            this.timet.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.timet.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timet.Location = new System.Drawing.Point(332, 306);
            this.timet.MaxLength = 5;
            this.timet.Name = "timet";
            this.timet.Size = new System.Drawing.Size(345, 32);
            this.timet.TabIndex = 7;
            this.timet.Text = "Time";
            this.timet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // datet
            // 
            this.datet.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.datet.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datet.Location = new System.Drawing.Point(332, 268);
            this.datet.MaxLength = 10;
            this.datet.Name = "datet";
            this.datet.Size = new System.Drawing.Size(345, 32);
            this.datet.TabIndex = 6;
            this.datet.Text = "Date ";
            this.datet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // addresst
            // 
            this.addresst.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.addresst.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresst.Location = new System.Drawing.Point(332, 230);
            this.addresst.MaxLength = 30;
            this.addresst.Name = "addresst";
            this.addresst.Size = new System.Drawing.Size(345, 32);
            this.addresst.TabIndex = 5;
            this.addresst.Text = "Address";
            this.addresst.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // typet
            // 
            this.typet.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.typet.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typet.Location = new System.Drawing.Point(332, 192);
            this.typet.MaxLength = 30;
            this.typet.Name = "typet";
            this.typet.Size = new System.Drawing.Size(345, 32);
            this.typet.TabIndex = 4;
            this.typet.Text = "Type";
            this.typet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // birthdayt
            // 
            this.birthdayt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.birthdayt.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.birthdayt.Location = new System.Drawing.Point(332, 154);
            this.birthdayt.MaxLength = 10;
            this.birthdayt.Name = "birthdayt";
            this.birthdayt.Size = new System.Drawing.Size(345, 32);
            this.birthdayt.TabIndex = 3;
            this.birthdayt.Text = "Birthday";
            this.birthdayt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // telet
            // 
            this.telet.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.telet.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.telet.Location = new System.Drawing.Point(332, 116);
            this.telet.MaxLength = 10;
            this.telet.Name = "telet";
            this.telet.Size = new System.Drawing.Size(345, 32);
            this.telet.TabIndex = 2;
            this.telet.Text = "Telephone";
            this.telet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // emailt
            // 
            this.emailt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.emailt.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailt.Location = new System.Drawing.Point(332, 78);
            this.emailt.MaxLength = 30;
            this.emailt.Name = "emailt";
            this.emailt.Size = new System.Drawing.Size(345, 32);
            this.emailt.TabIndex = 1;
            this.emailt.Text = "Email";
            this.emailt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // namet
            // 
            this.namet.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.namet.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namet.Location = new System.Drawing.Point(332, 40);
            this.namet.MaxLength = 30;
            this.namet.Name = "namet";
            this.namet.Size = new System.Drawing.Size(345, 32);
            this.namet.TabIndex = 0;
            this.namet.Text = "Name";
            this.namet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nm,
            this.mail,
            this.tel,
            this.bday,
            this.reytype,
            this.address,
            this.timereq,
            this.req_id});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.dataGridView1.RowTemplate.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.Size = new System.Drawing.Size(985, 553);
            this.dataGridView1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.input);
            this.panel3.Controls.Add(this.addpb);
            this.panel3.Controls.Add(this.editb);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(985, 66);
            this.panel3.TabIndex = 1;
            // 
            // input
            // 
            this.input.Location = new System.Drawing.Point(76, 24);
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(135, 20);
            this.input.TabIndex = 3;
            this.input.TextChanged += new System.EventHandler(this.input_TextChanged);
            // 
            // addpb
            // 
            this.addpb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.addpb.BackColor = System.Drawing.Color.White;
            this.addpb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("addpb.BackgroundImage")));
            this.addpb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addpb.Location = new System.Drawing.Point(832, 12);
            this.addpb.Name = "addpb";
            this.addpb.Size = new System.Drawing.Size(43, 42);
            this.addpb.TabIndex = 2;
            this.addpb.UseVisualStyleBackColor = false;
            this.addpb.Click += new System.EventHandler(this.addpb_Click);
            // 
            // editb
            // 
            this.editb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.editb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("editb.BackgroundImage")));
            this.editb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.editb.Location = new System.Drawing.Point(881, 12);
            this.editb.Name = "editb";
            this.editb.Size = new System.Drawing.Size(43, 42);
            this.editb.TabIndex = 1;
            this.editb.UseVisualStyleBackColor = true;
            this.editb.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(930, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(43, 42);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // requestBindingSource
            // 
            this.requestBindingSource.DataSource = typeof(KEP_crud.request);
            // 
            // nm
            // 
            this.nm.DataPropertyName = "name";
            this.nm.FillWeight = 105.5838F;
            this.nm.HeaderText = "Name";
            this.nm.Name = "nm";
            this.nm.ReadOnly = true;
            // 
            // mail
            // 
            this.mail.DataPropertyName = "email";
            this.mail.FillWeight = 105.5838F;
            this.mail.HeaderText = "Email";
            this.mail.Name = "mail";
            this.mail.ReadOnly = true;
            // 
            // tel
            // 
            this.tel.DataPropertyName = "tel";
            this.tel.FillWeight = 105.5838F;
            this.tel.HeaderText = "Telephone";
            this.tel.Name = "tel";
            this.tel.ReadOnly = true;
            // 
            // bday
            // 
            this.bday.DataPropertyName = "birthday";
            this.bday.FillWeight = 105.5838F;
            this.bday.HeaderText = "Birthday";
            this.bday.Name = "bday";
            this.bday.ReadOnly = true;
            // 
            // reytype
            // 
            this.reytype.DataPropertyName = "type";
            this.reytype.FillWeight = 105.5838F;
            this.reytype.HeaderText = "Request Type";
            this.reytype.Name = "reytype";
            this.reytype.ReadOnly = true;
            // 
            // address
            // 
            this.address.DataPropertyName = "address";
            this.address.FillWeight = 105.5838F;
            this.address.HeaderText = "Address";
            this.address.Name = "address";
            this.address.ReadOnly = true;
            // 
            // timereq
            // 
            this.timereq.DataPropertyName = "time";
            this.timereq.FillWeight = 105.5838F;
            this.timereq.HeaderText = "Time Of Request";
            this.timereq.Name = "timereq";
            this.timereq.ReadOnly = true;
            // 
            // req_id
            // 
            this.req_id.DataPropertyName = "req_id";
            this.req_id.HeaderText = "Request ID";
            this.req_id.Name = "req_id";
            this.req_id.ReadOnly = true;
            // 
            // crud
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 619);
            this.Controls.Add(this.panel1);
            this.Name = "crud";
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.requestBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource requestBindingSource;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button editb;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox timet;
        private System.Windows.Forms.TextBox datet;
        private System.Windows.Forms.TextBox addresst;
        private System.Windows.Forms.TextBox typet;
        private System.Windows.Forms.TextBox birthdayt;
        private System.Windows.Forms.TextBox telet;
        private System.Windows.Forms.TextBox emailt;
        private System.Windows.Forms.TextBox namet;
        private System.Windows.Forms.Button addb;
        private System.Windows.Forms.Button addpb;
        private System.Windows.Forms.Label errorl;
        private System.Windows.Forms.Button updbut;
        private System.Windows.Forms.PictureBox X;
        private System.Windows.Forms.TextBox input;
        private System.Windows.Forms.DataGridViewTextBoxColumn nm;
        private System.Windows.Forms.DataGridViewTextBoxColumn mail;
        private System.Windows.Forms.DataGridViewTextBoxColumn tel;
        private System.Windows.Forms.DataGridViewTextBoxColumn bday;
        private System.Windows.Forms.DataGridViewTextBoxColumn reytype;
        private System.Windows.Forms.DataGridViewTextBoxColumn address;
        private System.Windows.Forms.DataGridViewTextBoxColumn timereq;
        private System.Windows.Forms.DataGridViewTextBoxColumn req_id;
    }
}

