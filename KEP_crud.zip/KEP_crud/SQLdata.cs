﻿using Dapper;
using System;
using System.Data;

using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Web;
using static System.Net.Mime.MediaTypeNames;


namespace KEP_crud
{
    internal class SQLdata
    {
        public DataTable dt = new DataTable();

        public int exec()
        {
            this.getAll();





            return 1;
        }

        public int getByName(string n)
        {
            using (var connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\PANEP\\3o\\c#\\ask3\\KEP_crud\\database.mdf;Integrated Security=True"))
            {
                connection.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("name", n);
                var people = connection.ExecuteReader("sp_getByName", commandType: CommandType.StoredProcedure);
                dt.Load(people);
                connection.Close();
            }

            return 1;
        }


        public int insert(string n,string e,long t,string b,string ty,string ad,string ti,int r)
        {
            using (var connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\PANEP\\3o\\c#\\ask3\\KEP_crud\\database.mdf;Integrated Security=True"))
            {
                connection.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("name",n);
                parameters.Add("email", e);
                parameters.Add("tel", t);
                parameters.Add("birthday", b);
                parameters.Add("type", ty);
                parameters.Add("address", ad);
                parameters.Add("time", ti);
                parameters.Add("req_id", r);
                var people = connection.Query("sp_insertReq",parameters, commandType: CommandType.StoredProcedure);
                
                connection.Close();
            }

            return 1;
        }

        public int del(int id)
        {
            using (var connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\PANEP\\3o\\c#\\ask3\\KEP_crud\\database.mdf;Integrated Security=True"))
            {
                connection.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("id", id);
                var people = connection.ExecuteReader("sp_delReq",parameters, commandType: CommandType.StoredProcedure);
               
                connection.Close();
            }

            return 1;
        }

        public int getAll()
        {
            dt.Clear();
                using (var connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\PANEP\\3o\\c#\\ask3\\KEP_crud\\database.mdf;Integrated Security=True"))
                {
                    connection.Open();
                    var people = connection.ExecuteReader("sp_getAll", commandType: CommandType.StoredProcedure);
                    dt.Load(people);
                    connection.Close();
                }
          
            return 1;
        }

        public int update(string n, string e, long t, string b, string ty, string ad, string ti, int r)
        {
            using (var connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\PANEP\\3o\\c#\\ask3\\KEP_crud\\database.mdf;Integrated Security=True"))
            {
                connection.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("name", n);
                parameters.Add("email", e);
                parameters.Add("tel", t);
                parameters.Add("birthday", b);
                parameters.Add("type", ty);
                parameters.Add("address", ad);
                parameters.Add("time", ti);
                parameters.Add("req_id", r);
                var people = connection.Query("updReq", parameters, commandType: CommandType.StoredProcedure);
                connection.Close();
                this.getAll();
            }

            return 1;
        }

        public int updateD(string n, string e, long t, string b, string ty, string ad, string ti, int r)
        {
            using (var connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\PANEP\\3o\\c#\\ask3\\KEP_crud\\database.mdf;Integrated Security=True"))
            {
                connection.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("name", n);
                parameters.Add("email", e);
                parameters.Add("tel", t);
                parameters.Add("birthday", b);
                parameters.Add("type", ty);
                parameters.Add("address", ad);
                parameters.Add("time", ti);
                parameters.Add("req_id", r);
                var people = connection.Query("updDReq", parameters, commandType: CommandType.StoredProcedure);
                connection.Close();
                this.getAll();
            }

            return 1;
        }

        public int getByReqID(int r)
        {
            
            using (var connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\PANEP\\3o\\c#\\ask3\\KEP_crud\\database.mdf;Integrated Security=True"))
            {
                connection.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("req_id", r);
                var people = connection.ExecuteReader("sp_getByReqID", parameters, commandType: CommandType.StoredProcedure);
                dt.Load(people);
                connection.Close();
               
            }

            return 1;
        }




    }



}
