﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KEP_crud
{
    internal class request
    {
        public int len;
        public List<string> names = new List<string>();
        public List<string> emails = new List<string>();
        public List<long> tels = new List<long>();
        public List<string> birthdays = new List<string>();
        public List<string> types = new List<string>();
        public List<string> times = new List<string>();
        public List<int> req_ids = new List<int>();
        public List<string> addresses = new List<string>();
        List<int> indexes = new List<int>();

        public void add(string n, string e, long t, string b, string ty, string ad, string ti, int r)
        {
           
            names.Add(n);
            emails.Add(e);
            tels.Add(t);
            birthdays.Add(b);
            types.Add(ty);
            times.Add(ti);
            addresses.Add(ad);
            req_ids.Add(r);
            len = names.Count;
            Console.WriteLine(len);


        }

        public void print()
        {
            for(int i=0; i < names.Count; i++)
            {
                Console.WriteLine(names[i]+" "+ emails[i] + " " + tels[i] + " " + birthdays[i] + " " + types[i] + " " + addresses[i] + " " + times[i] + " " + req_ids[i] );
            }
            Console.WriteLine("Len is:" + len);
        }


        public void remove(int index)
        {

            names.RemoveAt(index);
            emails.RemoveAt(index);
            tels.RemoveAt(index);
            birthdays.RemoveAt(index);
            types.RemoveAt(index);
            times.RemoveAt(index);
            addresses.RemoveAt(index);
            req_ids.RemoveAt(index);
           
        }

        public List<int> search(string str)
        {
            indexes.Clear();

            int i = 0;
            foreach(var item in names)
            {
                Console.WriteLine("comparing " + str + " with " + item);
                if (item.ToLower().Contains(str.ToLower()))
                {
                    Console.WriteLine("Match");
                    if (!indexes.Contains(i))
                    {
                        Console.WriteLine("Added");
                        indexes.Add(i);
                    }
                }
                i++;


            }

            i = 0;
            foreach (var item in emails)
            {

                if (item.Contains(str))
                {
                    if (!indexes.Contains(i))
                    {
                        indexes.Add(i);
                    }
                }
                i++;


            }

            i = 0;
            foreach (var item in tels)
            {

                if (item.ToString().Contains(str))
                {
                    if (!indexes.Contains(i))
                    {
                        indexes.Add(i);
                    }
                }
                i++;


            }

            i = 0;
            foreach (var item in birthdays)
            {

                if (item.Contains(str))
                {
                    if (!indexes.Contains(i))
                    {
                        indexes.Add(i);
                    }
                }
                i++;


            }

            i = 0;
            foreach (var item in types)
            {

                if (item.ToLower().Contains(str.ToLower()))
                {
                    if (!indexes.Contains(i))
                    {
                        indexes.Add(i);
                    }
                }
                i++;


            }

            i = 0;
            foreach (var item in addresses)
            {

                if (item.ToLower().Contains(str.ToLower()))
                {
                    if (!indexes.Contains(i))
                    {
                        indexes.Add(i);
                    }
                }

                i++;

            }

            i = 0;
            foreach (var item in times)
            {

                if (item.Contains(str))
                {
                    if (!indexes.Contains(i))
                    {
                        indexes.Add(i);
                    }
                }

                i++;

            }




            return indexes;
        }






    }
}
