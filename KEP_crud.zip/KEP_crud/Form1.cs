﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace KEP_crud
{
    
    public partial class crud : Form
    {
        SQLdata s1 = new SQLdata();
        request reqHandler = new request();
        List<request> all_req = new List<request>();
        List<int> dis = new List<int>();
        public DataTable dtbl = new DataTable();
        public crud()
        {
            InitializeComponent();





           

           // s1.del(3);
            s1.exec();

      // s1.insert("Kostas Georgopoulos", "kostasgeo@gmail.com", 6983539123, "18-03-1995", "Προσωρινή Άδεια", "Σολωμού 12, 19004", "25-1-2023-13:02", 0);
      // s1.insert("Manolis Dimitriou", "m.dimi2009@gmail.com", 6941451529, "23-07-2009", "Ταυτότητα", "Αφροδίτης 88,17562", "17-12-2022-14:05", 1);
      // s1.insert("Xristos Dimitriou", "x.dimitriou@unipi.gr", 6941451529, "18-03-1973", "Επανέκδοση Διπλώματος", "Αφροδίτης 88,17562", "10-1-2023-10:10", 2);
      // s1.insert("Despina Pappadopoulou", "despi.pappa3@hotmail.com", 6942535947, "18-03-2003", "Έκδοση Διπλώματος", "Αγίας Άννης 23,17455", "25-1-2023-10:25", 3);
      // s1.insert("Filanthi Kostopoulou", "f.kostop.oulou@gmail.com", 6973409942, "18-03-2004", "Έκδοση Διπλώματος", "Σολωμού 12, 17456", "25-1-2023-09:18", 4 );
      // s1.insert("Manolis Dimitriou", "m.dimi2009@gmail.com", 6941451529, "23-07-2009", "Βιβλιάριο", "Αφροδίτης 88,17562", "10-1-2023-10:15", 5);
      // s1.insert("Kostas Georgopoulos", "kostasgeo@gmail.com", 6983539123, "18-03-1995", "Επανέκδοση Διπλώματος", "Σολωμού 12, 19004", "30-1-2023-14:02", 6);
      // s1.insert("Anastasia Dimitriou", "dimi.tasia@gov.gr", 6926436225, "18-03-1954", "Συνταξιοδοτηση", "Μουσών 2,17562", "25-1-2023-13:30", 7);
      //  s1.insert("Κωνσταντίνος Κούκος", "kostaskoukos@gmail.com", 6931151294, "23-09-2003", "Έκδοση Διαβατηρίου", "Βυζαντίου 9,17342", "25-1-2023-12:38", 8);
            s1.getAll();
            

            dataGridView1.DataSource = s1.dt;
            int i = 0;
            foreach (var row in dataGridView1.Rows)
            {
                string temp;

                string tempn = dataGridView1.Rows[i].Cells[0].Value.ToString();
                string tempe = dataGridView1.Rows[i].Cells[1].Value.ToString();
                temp = dataGridView1.Rows[i].Cells[2].Value.ToString();
                long tempte = Int64.Parse(temp);
                string tempb = dataGridView1.Rows[i].Cells[7].Value.ToString();
                string tempty = dataGridView1.Rows[i].Cells[3].Value.ToString();
                string tempad = dataGridView1.Rows[i].Cells[4].Value.ToString();
                string tempt = dataGridView1.Rows[i].Cells[5].Value.ToString();
                temp = dataGridView1.Rows[i].Cells[6].Value.ToString();
                int tempr = Int32.Parse(temp);


                reqHandler.add(tempn, tempe, tempte, tempb, tempty , tempad, tempt, tempr);
                all_req.Add(reqHandler);


                i++;
            }


            reqHandler.print();
           

        }

        private void add()
        {

        }

        
        private void del(int index)
        {
            s1.del(index);
            if (reqHandler.len > 1)
            {
                
                for (int i = 1 + index; i < reqHandler.len ; i++)
                {

                    s1.updateD(reqHandler.names[i], reqHandler.emails[i], reqHandler.tels[i], reqHandler.birthdays[i], reqHandler.types[i], reqHandler.addresses[i], reqHandler.times[i], reqHandler.req_ids[i]);
                    reqHandler.req_ids[i]--;

                }
                
            }

            reqHandler.len--;
            reqHandler.remove(index);
            s1.getAll();
            reqHandler.print();
            
        }

        private void edit(int index)
        {
            

        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (reqHandler.len > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this?", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    del(Int16.Parse(dataGridView1.SelectedCells[6].Value.ToString()));

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Console.WriteLine(dataGridView1.SelectedCells[6].Value.ToString());
            if (MessageBox.Show("Are you sure you want to edit this?", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)

            {
                addpb.Enabled = false;
                button1.Enabled = false;

                addb.Visible = false;
                updbut.Visible = true;
                panel2.Visible = true;
                int i = Int16.Parse(dataGridView1.SelectedCells[6].Value.ToString());
                edit(dataGridView1.CurrentRow.Index);
                panel2.Visible = true;
                namet.Text = reqHandler.names[i];
                emailt.Text = reqHandler.emails[i];
                telet.Text = reqHandler.tels[i].ToString();
                birthdayt.Text = reqHandler.birthdays[i];
                typet.Text = reqHandler.types[i];
                addresst.Text = reqHandler.addresses[i];
                //    reqHandler.req_ids[i]
                datet.Text = DateTime.Now.Day.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString();
                timet.Text = DateTime.Now.Hour.ToString() + ":";
                if (DateTime.Now.Minute > 10)
                {
                    timet.Text += DateTime.Now.Minute.ToString();
                }
                else
                {
                    timet.Text += "0" + DateTime.Now.Minute.ToString();
                }
            }
        }

       

        private void addpb_Click(object sender, EventArgs e)
        {
            editb.Enabled = false;
            button1.Enabled = false;
            addb.Visible = true;
            updbut.Visible = false;
            panel2.Visible = true;
            namet.Text = "Name";
            emailt.Text = "Email";
            telet.Text = "Telephone";
            birthdayt.Text = "Birthday";
            typet.Text = "Request Type";
            addresst.Text = "Address";
            datet.Text = DateTime.Now.Day.ToString()+"-"+ DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString();
            timet.Text = DateTime.Now.Hour.ToString()+":" ;
            if(DateTime.Now.Minute >10)
            {
                timet.Text += DateTime.Now.Minute.ToString();
            }
            else
            {
                timet.Text +="0"+ DateTime.Now.Minute.ToString();
            }
                
        }



        private int checkReg()
        {   
            string strRegex = "[A-Za-z α-ωΑ-Ωά-ώΆ-Ώ.]+$";
            Regex re = new Regex(strRegex, RegexOptions.IgnoreCase);
            if (!re.IsMatch(namet.Text))
            {
                return 1;
            }

            strRegex = "([A-Za-z_.!#$%&'*+-/=?^_`{|}~0-9]+)(\\@)([A-Za-z_!#$%&'*+-/=?^_`{|}~0-9]*)(\\.)[a-zA-Z]*$";
            re = new Regex(strRegex, RegexOptions.IgnoreCase);
            if (!re.IsMatch(emailt.Text))
            {
                return 2;
            }


            strRegex = "[0-9]{10}$";
            re = new Regex(strRegex, RegexOptions.IgnoreCase);
            if (!re.IsMatch(telet.Text))
            {
                return 3;
            }

            strRegex = "([1-9]|[0-2][1-9]|10|20|30|31)-([1-9]|(0[1-9])|10|11|12)-([0-9]{2}|19[0-9]{2}|20[0-9]{2})$";
            re = new Regex(strRegex, RegexOptions.IgnoreCase);
            if (!re.IsMatch(birthdayt.Text))
            {
                return 4;
            }

            strRegex = "[A-Za-z 0-9._{}()α-ωΑ-Ωά-ώΆ-Ώ]+$";
            re = new Regex(strRegex, RegexOptions.IgnoreCase);
            if (!re.IsMatch(typet.Text)) 
            {
                return 5;
            }

            strRegex = "[A-Za-z 0-9α-ωΑ-Ωά-ώΆ-Ώ.]+\\,( )*[0-9]{5}$";
            re = new Regex(strRegex, RegexOptions.IgnoreCase);
            if (!re.IsMatch(addresst.Text))
            {
                return 6;
            }

            strRegex = "([1-9]|[0-2][1-9]|10|20|30|31)-([1-9]|(0[1-9])|10|11|12)-([0-9]{2}|19[0-9]{2}|20[0-9]{2})$";
            re = new Regex(strRegex, RegexOptions.IgnoreCase);
            if (!re.IsMatch(datet.Text))
            {
                return 7;
            }

            strRegex = "([1-9]|[0-9]{2}):([1-9]|[0-9]{2})$";
            re = new Regex(strRegex, RegexOptions.IgnoreCase);
            if (!re.IsMatch(timet.Text))
            {
                return 8;
            }

            return 0;
        }

        private void upd_Click(object sender, EventArgs e)
        {

            var temp = checkReg();
            Console.WriteLine(temp);

            if (temp == 0)
            {
                int i = dataGridView1.CurrentRow.Index;
                s1.update(namet.Text, emailt.Text, long.Parse(telet.Text), birthdayt.Text, typet.Text, addresst.Text, datet.Text + "-" + timet.Text, reqHandler.req_ids[i]);
                reqHandler.names[i] = namet.Text;
                reqHandler.emails[i] = emailt.Text;
                reqHandler.tels[i] = long.Parse(telet.Text);
                reqHandler.birthdays[i] = birthdayt.Text;
                reqHandler.types[i] = typet.Text;
                reqHandler.addresses[i] = addresst.Text;
                reqHandler.times[i] = datet.Text + "-" + timet.Text;
                panel2.Visible = false;
                addpb.Enabled = true;
                button1.Enabled = true;
                editb.Enabled = true;
                errorl.Text = "";

            }
            else if (temp == 1)
            {
                errorl.Text = "ERROR: Wrong name ( A-Z a-z α-ζ Α-Ζ)  ";
            }
            else if (temp == 2)
            {
                errorl.Text = "ERROR: Wrong email ( foo@bar.foo ) ";
            }
            else if (temp == 3)
            {
                errorl.Text = "ERROR: Wrong telephone ( 10 number strictly ) ";
            }
            else if (temp == 4)
            {
                errorl.Text = "ERROR: Wrong Birhtday ( 00-00-00 /0-0-00 use any combination of the previous ) ";
            }
            else if (temp == 5)
            {
                errorl.Text = "ERROR: Wrong type ";
            }
            else if (temp == 6)
            {
                errorl.Text = "ERROR: Wrong address (address , 00000 <-Postal Code) ";
            }
            else if (temp == 7)
            {
                errorl.Text = "ERROR: Wrong date ( 00-00-00 /0-0-00 use any combination of the previous ) ";
            }
            else if (temp == 8)
            {
                errorl.Text = "ERROR: Wrong time ( 00:00/0:0 use any combination of the previous ) ";
            }



            s1.getAll();

        }

        private void addb_Click(object sender, EventArgs e)
        {
            
            var temp = checkReg();
           Console.WriteLine( temp);

            if (temp == 0)
            {
                s1.insert(namet.Text, emailt.Text, long.Parse( telet.Text), birthdayt.Text, typet.Text, addresst.Text, datet.Text + "-" + timet.Text,reqHandler.len);
                reqHandler.add(namet.Text, emailt.Text, long.Parse(telet.Text), birthdayt.Text, typet.Text, addresst.Text, datet.Text + "-" + timet.Text, reqHandler.len);
                panel2.Visible = false;
                addpb.Enabled = true;
                button1.Enabled = true;
                editb.Enabled = true;
                errorl.Text = "";
            }
            else if (temp == 1)
            {
                errorl.Text = "ERROR: Wrong name ( A-Z a-z α-ζ Α-Ζ)  ";
            }
            else if (temp == 2)
            {
                errorl.Text = "ERROR: Wrong email ( foo@bar.foo ) ";
            }
            else if (temp == 3)
            {
                errorl.Text = "ERROR: Wrong telephone ( 10 number strictly ) ";
            }
            else if (temp == 4)
            {
                errorl.Text = "ERROR: Wrong Birhtday ( 00-00-00 /0-0-00 use any combination of the previous ) ";
            }
            else if (temp == 5)
            {
                errorl.Text = "ERROR: Wrong type ";
            }
            else if (temp == 6)
            {
                errorl.Text = "ERROR: Wrong address (address , 00000 <-Postal Code) ";
            }
            else if (temp == 7)
            {
                errorl.Text = "ERROR: Wrong date ( 00-00-00 /0-0-00 use any combination of the previous ) ";
            }
            else if (temp == 8)
            {
                errorl.Text = "ERROR: Wrong time ( 00:00/0:0 use any combination of the previous ) ";
            }



            s1.getAll();

        }

        private void X_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;

            addpb.Enabled = true;
            button1.Enabled = true;
            editb.Enabled = true;
            s1.getAll();
        }

        private void input_TextChanged(object sender, EventArgs e)
        {
            if(!(input.Text == ""|input.Text==" "))
            {
                dis.Clear();
                dis = reqHandler.search(input.Text);
                dis.ForEach(Console.WriteLine);
                dtbl.Clear();
                s1.dt.Clear();
                foreach( int index in dis)
                {
                    s1.getByReqID(index);
                }
            }
            else
            {
                s1.getAll();
            }
        }
    }
}
